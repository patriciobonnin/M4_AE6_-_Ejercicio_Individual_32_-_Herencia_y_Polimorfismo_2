public class Contratado extends Trabajador {

    private String fechaIngreso;
    private double salarioMensual;

    public Contratado(String fechaIngreso, double salarioMensual) {
        this.fechaIngreso = fechaIngreso;
        this.salarioMensual = salarioMensual;
    }

    public Contratado(String nombres, String apellidos, String run, int telefono, int edad, String fechaIngreso, double salarioMensual) {
        super(nombres, apellidos, run, telefono, edad);
        this.fechaIngreso = fechaIngreso;
        this.salarioMensual = salarioMensual;
    }

    public String getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(String fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public double getSalarioMensual() {
        return salarioMensual;
    }

    public void setSalarioMensual(double salarioMensual) {
        this.salarioMensual = salarioMensual;
    }

    public void mostrarDatos() {
        super.mostrarDatos();
        System.out.println("Fecha de Ingreso: " + this.fechaIngreso);
        System.out.println("Salario Mensual: " + this.salarioMensual);

    }

    @Override
    public String toString() {
        return "Contratado{" +
                "fechaIngreso='" + fechaIngreso + '\'' +
                ", salarioMensual=" + salarioMensual +
                '}';
    }
}
