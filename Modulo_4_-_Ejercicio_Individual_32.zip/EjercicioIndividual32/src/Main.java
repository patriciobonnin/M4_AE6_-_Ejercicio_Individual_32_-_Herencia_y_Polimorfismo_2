public class Main {

    public static void main(String[] args){


        Listado lista = new Listado();
        Honorario honorario = new Honorario("Emetrio", "Gatica Guajardo", "11472270", 65565656, 37, 100000, 2022) ;
        Honorario honorario2 = new Honorario("Rosa","Cifuentes","75729731",932874230,60,1000000,2001);
        Eventual eventual = new Eventual("Patricio","Bonnin","45564645-2",14552554,35,true,"patriciobonnin@gmail.com");
        Eventual eventual2 = new Eventual("Marta","Hasla","65878922-7",6543218,40,false,"martahasla@gmail.com");
        Contratado contratado = new Contratado("Ivan","Mieres","7987987-5",45654654,25,"10/05/1959",800000);


        lista.addTrabajador(honorario);
        lista.addTrabajador(honorario2);
        lista.addTrabajador(eventual);
        lista.addTrabajador(eventual2);
        lista.addTrabajador(contratado);

        lista.mostrarLista();


    }
}
