public interface Corredora {

    public void mostrarDatos();

}
