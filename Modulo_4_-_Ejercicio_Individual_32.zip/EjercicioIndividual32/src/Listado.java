import java.util.ArrayList;
import java.util.List;

public class Listado {

    List<Trabajador> lista;

    public Listado() {
        this.lista = new ArrayList<>();
    }

    public void addTrabajador(Trabajador trabajador){
        this.lista.add(trabajador);
    }


    public void mostrarLista(){

        for (Trabajador trabajador: lista){

            trabajador.mostrarDatos();

        }

    }
}
